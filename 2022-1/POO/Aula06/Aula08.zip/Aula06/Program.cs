﻿using Aula06.Controllers;

namespace Aula06
{
    internal class Program
    {
        private static void Main(string[] args)
        {
             var controller = new Controller();
             controller.Menu();
        }
    }
}