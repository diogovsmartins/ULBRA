const { sum, isMultiple, calcDaysPassed } = require('./my-code')


describe('math functions', () => {
    // beforeAll(() => {
    //     console.log('before all');
    // })

    // beforeEach(() => {
    //     console.log('before each');
    // })

    // afterAll(() => {
    //     console.log('after all');
    // })

    // afterEach(() => {
    //     console.log('after each');
    // })

    // it('sums 2 numbers', () => {
    //     expect(sum(2,2)).toBe(4)
    // })

})

describe('functions is multiple', () => {
    it('is Multiple', () => {
        expect(isMultiple(2, 4)).toBe(true)
    })
})

describe('functions dates', () => {
    it('calc days passed', () => {
        expect(calcDaysPassed(new Date(2037, 3, 5), new Date(2037, 3, 10))).toBe(10)
    })
})