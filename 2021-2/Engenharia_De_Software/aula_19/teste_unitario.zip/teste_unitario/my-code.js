const sum = (a, b) => {
    return a + b
}

const isMultiple = (multiple, number) => {
    if(number%multiple === 0) {
        console.log(`${number} é múltiplo de ${multiple}`);
        return true
    }
}

const calcDaysPassed = (date1, date2) =>
  Math.abs(date2 - date1) / (1000 * 60 * 60 * 24);

module.exports = { sum, isMultiple, calcDaysPassed}
