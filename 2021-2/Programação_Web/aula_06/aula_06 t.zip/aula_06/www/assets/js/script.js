$(document).ready(function(){

    $("#add").click(function(){
        $("#text").append(`
        <br>FUNCIONOU MUITO BEM FUNCIONADO
        <p>lorem*0.5</p>
        `);
    })
  
  });