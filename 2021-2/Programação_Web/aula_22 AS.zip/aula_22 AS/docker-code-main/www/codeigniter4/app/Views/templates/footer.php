        </section>
        </div>
   </div>
<footer class="jumbotron text-center mb-0 fluid">
        <p>All rights reserved to Ariana Almeida</p>
        <a class="text-info" href="<?=base_url('admin')?>">Área admnistrativa</a>
</footer>
