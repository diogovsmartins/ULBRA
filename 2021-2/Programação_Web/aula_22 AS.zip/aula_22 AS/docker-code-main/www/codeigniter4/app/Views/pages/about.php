<h2>Sobre</h2>
<p id="text">
Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quod, distinctio velit voluptas mollitia rem praesentium possimus illo consequuntur neque soluta quia. Sequi optio facilis quo. Reiciendis aliquid quas doloribus pariatur?
Obcaecati, delectus quaerat rerum pariatur perspiciatis modi vitae recusandae nisi minus aliquam, nobis saepe. Officiis maxime quis nisi, recusandae obcaecati animi architecto facere sapiente beatae laboriosam, error reiciendis porro.

</p>