        </section>
        </div>
   </div>
<footer class="jumbotron text-center mb-0">
        <p>All rights reserved to Ariana Almeida</p>
        <a class="text-info" href="<?=base_url('home')?>">Área publica do site</a>
</footer>
