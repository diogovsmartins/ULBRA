<h2>Sobre a empresa</h2>
<p id="text">
    Texto incrivel que fala sobre a empresa. show.
</p>