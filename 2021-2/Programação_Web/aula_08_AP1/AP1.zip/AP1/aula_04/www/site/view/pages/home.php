
<h2>Conteudo qualquer</h2>
<p id="text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam tempora itaque necessitatibus dignissimos laboriosam voluptate quibusdam quam ipsum hic autem illum neque nostrum ipsam qui provident, impedit facere voluptas. Quidem.
Deleniti, voluptate! Voluptatibus architecto dignissimos aspernatur pariatur cum, earum ducimus molestiae eaque, error officia veniam nisi tenetur ad delectus tempora optio saepe, quos impedit sit nihil sint ipsum nostrum corporis?
</p>
<button class="btn-info" id="add">Click-me</button>
</div>
   </div>